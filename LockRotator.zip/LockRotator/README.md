# Lock Rotator
Меняет обои экрана блокировки при каждом выключении экрана.
Сборка APK: вкладка Actions на GitHub -> Build APK -> Artifacts.
