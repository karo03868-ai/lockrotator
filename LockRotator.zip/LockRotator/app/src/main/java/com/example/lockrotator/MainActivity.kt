package com.example.lockrotator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        info = TextView(this).apply { textSize = 18f }

        val pick = Button(this).apply {
            text = "Выбрать картинки"
            setOnClickListener { pickImages() }
        }
        val clear = Button(this).apply {
            text = "Очистить список"
            setOnClickListener { Prefs.clear(context); refresh() }
        }
        val sw = Switch(this).apply {
            text = "Менять обои при выключении экрана"
            isChecked = Prefs.isEnabled(context)
            setOnCheckedChangeListener { _, on ->
                Prefs.setEnabled(context, on)
                val svc = Intent(context, WallpaperService::class.java)
                if (on) startForegroundService(svc) else stopService(svc)
            }
        }
        val battery = Button(this).apply {
            text = "Настройки экономии батареи"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = pad }
        listOf(info, pick, clear, sw, battery).forEach { root.addView(it, lp) }
        setContentView(root)
        refresh()
    }

    private fun refresh() {
        info.text = "Картинок в списке: ${Prefs.uris(this).size}"
    }

    private fun pickImages() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
        startActivityForResult(i, 100)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 100 || res != RESULT_OK || data == null) return
        val uris = mutableListOf<android.net.Uri>()
        data.clipData?.let { cd -> for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri) }
        data.data?.let { uris.add(it) }
        uris.forEach {
            try {
                contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
        }
        Prefs.add(this, uris)
        refresh()
    }
}
