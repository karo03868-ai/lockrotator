package com.example.lockrotator

import android.content.Context
import android.net.Uri

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    fun uris(c: Context): List<Uri> =
        sp(c).getString("uris", "")!!.split("\n").filter { it.isNotBlank() }.map(Uri::parse)

    fun add(c: Context, new: List<Uri>) {
        val all = (uris(c) + new).distinct()
        sp(c).edit().putString("uris", all.joinToString("\n")).apply()
    }

    fun clear(c: Context) = sp(c).edit().remove("uris").remove("last").apply()

    fun isEnabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun last(c: Context): String? = sp(c).getString("last", null)
    fun setLast(c: Context, v: String) = sp(c).edit().putString("last", v).apply()
}
