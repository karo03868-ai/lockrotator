package com.example.lockrotator

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED && Prefs.isEnabled(c)) {
            c.startForegroundService(Intent(c, WallpaperService::class.java))
        }
    }
}
