package com.example.lockrotator

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.IBinder
import android.util.Log
import java.util.concurrent.Executors
import kotlin.math.ceil
import kotlin.math.max

class WallpaperService : Service() {
    private val executor = Executors.newSingleThreadExecutor()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            executor.execute { changeWallpaper() }
        }
    }

    override fun onCreate() {
        super.onCreate()
        registerReceiver(receiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
        startAsForeground()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("main", "Lock Rotator", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "main")
            .setContentTitle("Lock Rotator работает")
            .setContentText("Обои экрана блокировки меняются при выключении экрана")
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun changeWallpaper() {
        val list = Prefs.uris(this)
        if (list.isEmpty()) return
        val last = Prefs.last(this)
        val pool = if (list.size > 1) list.filter { it.toString() != last } else list
        val uri = pool.random()
        try {
            val dm = resources.displayMetrics
            val w = dm.widthPixels
            val h = dm.heightPixels

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= w && bounds.outHeight / (sample * 2) >= h) sample *= 2

            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val src = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return

            // масштаб "cover" + обрезка по центру под размер экрана
            val scale = max(w.toFloat() / src.width, h.toFloat() / src.height)
            val sw = max(w, ceil(src.width * scale).toInt())
            val sh = max(h, ceil(src.height * scale).toInt())
            val scaled = Bitmap.createScaledBitmap(src, sw, sh, true)
            val out = Bitmap.createBitmap(scaled, (sw - w) / 2, (sh - h) / 2, w, h)

            WallpaperManager.getInstance(this)
                .setBitmap(out, null, true, WallpaperManager.FLAG_LOCK)
            Prefs.setLast(this, uri.toString())
        } catch (e: Exception) {
            Log.e("LockRotator", "Не удалось сменить обои", e)
        }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onDestroy() {
        unregisterReceiver(receiver)
        executor.shutdown()
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
